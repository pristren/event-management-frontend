import React from "react";

const MapMarker = () => {
  return <div className="marker" title="hello from dhaka"></div>;
};

export default MapMarker;
