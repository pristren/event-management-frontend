import { createContext } from "react";

const MyProvider = createContext();
export default MyProvider;
